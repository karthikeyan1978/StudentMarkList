/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package com.apps.constants;

/**
 *
 * @author KIRUBA
 */
public class Constants 
{
    public static String Config = "StudentMarkconfig";   
}
